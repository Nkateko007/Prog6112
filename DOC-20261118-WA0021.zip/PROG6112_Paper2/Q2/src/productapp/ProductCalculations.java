package productapp;

/**
 * Calculates VAT, commission and the total sale amount for a product price.
 */
public class ProductCalculations implements IProductCalculations {

    public static final double VAT_RATE = 0.15;        // 15% of the price
    public static final double COMMISSION_RATE = 0.05; // 5% of the price

    private final double price;

    public ProductCalculations(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        this.price = price;
    }

    @Override
    public double GetVat() {
        return price * VAT_RATE;
    }

    @Override
    public double GetCommission() {
        return price * COMMISSION_RATE;
    }

    /** Total sale amount = price + VAT + commission. */
    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
