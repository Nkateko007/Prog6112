package productapp;

/**
 * Contract for the sale calculations (as given in Q.2.5).
 */
public interface IProductCalculations {
    double GetVat();

    double GetCommission();

    double GetTotal();
}
