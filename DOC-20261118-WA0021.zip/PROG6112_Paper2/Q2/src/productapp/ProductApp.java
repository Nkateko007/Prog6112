package productapp;

import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ProductApp extends JFrame {

    private static final String FILE_NAME = "data.txt";
    private static final String STARS = "*".repeat(30);
    private static final String[] PRODUCTS =
            {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};

    private final JTextField customerField = new JTextField(20);
    private final JComboBox<String> productCombo = new JComboBox<>(PRODUCTS);
    private final JTextField priceField = new JTextField(20);
    private final JButton processButton = new JButton("PROCESS");

    public ProductApp() {
        super("Product App");
        BuildMenu();
        BuildForm();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void BuildMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> ExitApplication());
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        processItem.addActionListener(e -> ProcessSale()); // same logic as the button
        clearItem.addActionListener(e -> ClearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    private void BuildForm() {
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 15));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(new JLabel("Customer Name:"));
        form.add(customerField);
        form.add(new JLabel("Select Product:"));
        form.add(productCombo);
        form.add(new JLabel("Enter Price:"));
        form.add(priceField);
        form.add(new JLabel()); // empty cell so the button lines up with the inputs
        form.add(processButton);

        processButton.addActionListener(e -> ProcessSale());
        setContentPane(form);
    }

    /** Process button / Tools > Process. Validates, calculates, saves and displays. */
    private void ProcessSale() {
        String customer = customerField.getText().trim();
        if (customer.isEmpty()) {
            ShowError("Please enter the customer's name.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceField.getText().trim());
        } catch (NumberFormatException ex) {
            ShowError("Please enter a valid numeric price.");
            return;
        }
        if (price < 0) {
            ShowError("The price cannot be negative.");
            return;
        }

        ProductCalculations calc = new ProductCalculations(price);
        String details = BuildDetails(customer, (String) productCombo.getSelectedItem(), calc);

        // The same text is saved to the file and shown in the message box
        if (SaveToFile(details)) {
            JOptionPane.showMessageDialog(this, details);
        }
    }

    /** Builds the five lines of sale details. */
    private String BuildDetails(String customer, String product, IProductCalculations calc) {
        return "Customer Name: " + customer + "\n"
                + "Product: " + product + "\n"
                + "VAT: R " + calc.GetVat() + "\n"
                + "COMMISSION: R " + calc.GetCommission() + "\n"
                + "TOTAL: R " + calc.GetTotal();
    }

    /** Writes the DATA LOG file; returns false (after telling the user) on failure. */
    private boolean SaveToFile(String details) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            writer.println("DATA LOG");
            writer.println(STARS);
            writer.println(details);
            writer.println(STARS);
            return true;
        } catch (IOException ex) {
            ShowError("Could not save " + FILE_NAME + ": " + ex.getMessage());
            return false;
        }
    }

    /** Tools > Clear: empties the text boxes and resets the combo box to the first item. */
    private void ClearForm() {
        customerField.setText("");
        priceField.setText("");
        productCombo.setSelectedIndex(0);
    }

    /** File > Exit. */
    private void ExitApplication() {
        dispose();
        System.exit(0);
    }

    private void ShowError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
