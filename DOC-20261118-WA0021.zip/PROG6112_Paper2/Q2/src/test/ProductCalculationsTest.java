package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import productapp.ProductCalculations;

public class ProductCalculationsTest {

    private static final double PRICE = 3500; // from the sample screenshot

    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(PRICE);

        assertEquals(525.0, calc.GetVat(), 0.001);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(PRICE);

        // 3500 + 525 + 175
        assertEquals(4200.0, calc.GetTotal(), 0.001);
    }

    @Test
    public void GetCommission_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(PRICE);

        assertEquals(175.0, calc.GetCommission(), 0.001);
    }
}
