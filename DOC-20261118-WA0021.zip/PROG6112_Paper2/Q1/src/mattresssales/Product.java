package mattresssales;

/**
 * Holds the sales data and performs the report calculations.
 *
 * productNames : single-dimensional array, one entry per product.
 * monthlySales : two-dimensional array, [product][month].
 */
public class Product implements IProduct {

    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        if (productNames == null || monthlySales == null
                || productNames.length == 0
                || productNames.length != monthlySales.length) {
            throw new IllegalArgumentException(
                    "Each product needs a name and a row of monthly sales.");
        }
        this.productNames = productNames;
        this.monthlySales = monthlySales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int product = 0; product < monthlySales.length; product++) {
            total += GetProductTotal(product);
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int entries = 0;
        for (int[] months : monthlySales) {
            entries += months.length;
        }
        // Guard against division by zero
        return entries == 0 ? 0 : (double) GetTotalProductsSold() / entries;
    }

    /**
     * The most popular product is the one with the highest total sales.
     * The figure in brackets is that product's best monthly sale, which is
     * how the sample output in the paper is displayed (Cozy Nights Monarch(25)).
     */
    @Override
    public String GetMostPopularProduct() {
        int bestProduct = 0;
        for (int product = 1; product < monthlySales.length; product++) {
            if (GetProductTotal(product) > GetProductTotal(bestProduct)) {
                bestProduct = product;
            }
        }
        return productNames[bestProduct] + "(" + GetBestMonth(bestProduct) + ")";
    }

    /** Total sales for one product over all months. */
    private int GetProductTotal(int product) {
        int total = 0;
        for (int sale : monthlySales[product]) {
            total += sale;
        }
        return total;
    }

    /** Highest single-month sale for one product. */
    private int GetBestMonth(int product) {
        int best = 0;
        for (int sale : monthlySales[product]) {
            if (sale > best) {
                best = sale;
            }
        }
        return best;
    }
}
