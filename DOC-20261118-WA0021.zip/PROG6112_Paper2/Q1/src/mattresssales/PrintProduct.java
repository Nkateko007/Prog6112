package mattresssales;

/**
 * Responsible only for printing the report data (Q.1.3).
 */
public class PrintProduct {

    private static final String STARS = "*".repeat(50);

    private final IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    /** Prints the whole report in the order shown in the sample. */
    public void PrintReport() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println(STARS);
        PrintTotalProductSales();
        PrintAverageProductSales();
        PrintMostPopularProduct();
    }

    public void PrintTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales() {
        // Rounded to a whole number, as in the sample (17)
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductSold());
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
