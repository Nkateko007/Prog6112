package mattresssales;

/**
 * Contract for the product sales calculations (as given in Q.1.2).
 */
public interface IProduct {

    /** Total number of products sold across all products and months. */
    int GetTotalProductsSold();

    /** Average number of products sold (total / number of sales entries). */
    double GetAverageProductSold();

    /** Name of the most popular product, e.g. "Cozy Nights Monarch(25)". */
    String GetMostPopularProduct();
}
