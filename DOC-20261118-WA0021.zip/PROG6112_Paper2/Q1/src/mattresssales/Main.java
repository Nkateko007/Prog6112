package mattresssales;

import java.util.Scanner;

public class Main {

    private static final int MONTHS = 3;

    public static void main(String[] args) {
        // Single-dimensional array: product names
        String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        // Two-dimensional array: [product][month]
        int[][] monthlySales = new int[productNames.length][MONTHS];

        Scanner input = new Scanner(System.in);

        for (int product = 0; product < productNames.length; product++) {
            for (int month = 0; month < MONTHS; month++) {
                monthlySales[product][month] =
                        ReadSales(input, month + 1, productNames[product]);
            }
            System.out.println(); // blank line between products, as in the sample
        }

        PrintProduct printer = new PrintProduct(new Product(productNames, monthlySales));
        printer.PrintReport();
    }

    /** Keeps asking until the user enters a whole number that is 0 or more. */
    private static int ReadSales(Scanner input, int month, String productName) {
        while (true) {
            System.out.print("Enter number of sales for month " + month
                    + " for " + productName + " mattress: ");
            try {
                int sales = Integer.parseInt(input.nextLine().trim());
                if (sales >= 0) {
                    return sales;
                }
            } catch (NumberFormatException ex) {
                // fall through to the error message below
            }
            System.out.println("Please enter a whole number of 0 or more.");
        }
    }
}
